# Student Management System — Frontend Only

This version runs only React + Vite. It does not require Express or MongoDB.

## Run it
1. Install Node.js (18 or later).
2. Extract this ZIP and open this folder in VS Code.
3. Open the VS Code terminal in this folder:
   ```bash
   npm install
   npm run dev
   ```
4. Open the local URL printed by Vite, usually `http://localhost:5173`.

## Demo login
Register a new account on the registration page, then sign in. The demo stores the account and student records in your browser's `localStorage`, not in MongoDB. Use this for a classroom UI demonstration only; it is not secure authentication and the data stays in that browser.

## Features
- Login and registration UI with validation and show/hide password
- Dashboard with student summary cards
- Profile editing
- Student records add, view, edit, delete, and search
- Responsive blue-and-white layout

## Important
This is intentionally frontend-only. Passwords and demo data are stored in the browser to make the UI demonstrable without a backend. Do not use real passwords or personal information.
